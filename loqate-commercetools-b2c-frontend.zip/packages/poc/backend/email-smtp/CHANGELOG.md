
## Version 1.1.0 (2023-09-27)

** New Features and Improvements **

- Implemented fall back into project config if studio config is not set for all extensions

## Version 1.0.0 (2023-04-21)

* Stable version

## Version 1.0.0-alpha.1 (2023-04-21)

* Initial commit with all code for extension smtp
