import { ExtensionRegistry } from '@frontastic/extension-types';

export default {
  'data-sources': {},
  actions: {},
} as ExtensionRegistry;
