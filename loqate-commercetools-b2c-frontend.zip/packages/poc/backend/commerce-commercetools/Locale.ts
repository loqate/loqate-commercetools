export interface Locale {
  language: string;
  country: string;
  currency: string;
}
