export interface LoqateAddressCaptureRequest {
  id?: string;
  text: string;
  countryIsoCode: string;
  limit?: number;
  city?: number;
}
