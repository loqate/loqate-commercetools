export interface LoqateValidateEmailRequest {
  email?: string;
}
