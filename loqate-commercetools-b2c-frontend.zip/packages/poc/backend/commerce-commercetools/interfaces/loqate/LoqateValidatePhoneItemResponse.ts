export interface LoqateValidatePhoneItemResponse {
  isValid: boolean;
}
