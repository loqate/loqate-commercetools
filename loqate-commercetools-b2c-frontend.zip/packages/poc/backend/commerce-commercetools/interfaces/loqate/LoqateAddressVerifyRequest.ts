export interface LoqateAddressVerifyRequest {
  country: string;
  address: string;
  city: string;
  postalCode: string;
}
