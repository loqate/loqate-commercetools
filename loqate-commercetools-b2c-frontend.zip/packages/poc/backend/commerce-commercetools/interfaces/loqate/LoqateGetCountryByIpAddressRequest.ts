export interface LoqateGetCountryByIpAddressRequest {
  ip: string;
}
