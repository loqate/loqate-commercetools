import { LoqateValidateEmailItemResponse } from './LoqateValidateEmailItemResponse';

interface LoqateValidateEmailResponse {
  items: LoqateValidateEmailItemResponse[];
}
