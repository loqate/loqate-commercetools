export interface LoqateAddressVerifyResponse {
  status: string;
  address1: string;
  country: string;
  postalCode: string;
  locality: string;
}
