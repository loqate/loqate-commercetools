export interface LoqateValidateEmailItemResponse {
  responseCode: string;
  isValid: boolean;
}
