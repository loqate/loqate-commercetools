export interface LoqateGetCountryByIpAddressResponse {
  iso2: string;
  iso3: string;
  country: string;
}
