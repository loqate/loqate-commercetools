export interface LoqateValidatePhoneRequest {
  phone?: string;
  country?: string;
}
