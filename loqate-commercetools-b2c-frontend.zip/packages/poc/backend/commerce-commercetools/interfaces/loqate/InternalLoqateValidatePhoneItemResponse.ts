export interface InternalLoqateValidatePhoneItemResponse {
  isValid?: string;
}
