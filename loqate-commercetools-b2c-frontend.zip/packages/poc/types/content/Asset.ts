export interface Asset {
  url: string;
  title?: string;
  description?: string;
}
