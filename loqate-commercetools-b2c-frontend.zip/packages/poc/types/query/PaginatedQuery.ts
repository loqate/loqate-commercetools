export interface PaginatedQuery {
  limit?: number;
  cursor?: string;
}
