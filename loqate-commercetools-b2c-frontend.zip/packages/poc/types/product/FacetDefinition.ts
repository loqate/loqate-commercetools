export interface FacetDefinition {
  attributeType?: string;
  attributeId?: string;
  attributeLabel?: string;
}
