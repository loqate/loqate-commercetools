export interface Attributes {
  [key: string]: any;
}
