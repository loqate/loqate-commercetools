export interface AuthenticationInformation {
  email: string;
  password: string;
  newPassword: string;
}
