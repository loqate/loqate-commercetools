export interface AccountToken {
  email?: string;
  token?: string;
  tokenValidUntil?: Date;
}
