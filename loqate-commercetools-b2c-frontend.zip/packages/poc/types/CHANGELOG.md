
## Version 1.5.1 (2024-05-09)

## Version 1.5.0 (2024-04-22)

** New Features and Improvements **

- Added default store types

## Version 1.5.0 (2024-04-22)

** New Features and Improvements **

- Added select store types

## Version 1.4.0 (2024-02-22)

** New Features and Improvements **

- Refactor product mapper to use a helper method
- Add discount details for b2c

## Version 1.3.0 (2023-09-27)

** New Features and Improvements **

- Added type to export
- Added index files for domain types
- Removed unused methods for shipping
- Added human readable facet label

## Version 1.2.0 (2023-08-29)

** New Features and Improvements **

- Added discounts to shipping info
- Return human readable facet label

## Version 1.1.0 (2023-02-03)

** New Features and Improvements **

- Added Token type

# Version 1.0.1 (2022-07-20)

** New Features and Improvements **

- Initial stable release

## Version 1.0.0 (2022-07-20)

* misc: Tagged release 1.0.0 for types
