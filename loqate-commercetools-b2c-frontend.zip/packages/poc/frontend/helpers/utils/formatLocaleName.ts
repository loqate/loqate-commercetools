export const formatLocaleName = (localeName: string) => {
  return localeName.slice(0, 2).toUpperCase();
};
