export const REMEMBER_ME = '__rememberMe';
export const PREF_DARK_MODE = '__pref_dark_mode';
export const ANONYMOUS_USER_TOKEN = '__anonUserToken';
export const LAST_ALGOLIA_QUERY_ID = '__lastAlgoliaQId';
