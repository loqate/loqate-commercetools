export const productsIndex_US = process.env.NEXT_PUBLIC_ALGOLIA_PRODUCTS_INDEX_US || '';
export const productsIndex_DE = process.env.NEXT_PUBLIC_ALGOLIA_PRODUCTS_INDEX_DE || '';

export const productsQuerySuggestionsIndex_US =
  process.env.NEXT_PUBLIC_ALGOLIA_PRODUCTS_QUERY_SUGGESTIONS_INDEX_US || '';
export const productsQuerySuggestionsIndex_DE =
  process.env.NEXT_PUBLIC_ALGOLIA_PRODUCTS_QUERY_SUGGESTIONS_INDEX_DE || '';
