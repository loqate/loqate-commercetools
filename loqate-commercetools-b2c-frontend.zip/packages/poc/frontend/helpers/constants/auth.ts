export const SESSION_PERSISTENCE = 1000 * 60 * 60 * 24 * 30 * 3; //3 months
