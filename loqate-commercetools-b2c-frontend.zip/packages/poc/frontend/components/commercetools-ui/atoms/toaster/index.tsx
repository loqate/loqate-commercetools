import React from 'react';
import { Toaster as ReactToaster } from 'react-hot-toast';

const Toaster = () => {
  return <ReactToaster />;
};

export default Toaster;
