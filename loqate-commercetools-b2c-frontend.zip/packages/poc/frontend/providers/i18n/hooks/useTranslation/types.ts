export interface TranslationOptions {
  values?: Record<string, string | number>;
  defaultMessage?: string;
}
